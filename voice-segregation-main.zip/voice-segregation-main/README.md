# voice-segregation

Single channel voice segregation using Tasnet.

got references from : 
Self-supervised Pre-training Reduces Label Permutation Instability of Speech Separation https://arxiv.org/abs/2010.15366v1
Continuous speech separation: dataset and analysis https://arxiv.org/abs/2001.11482v3
Dual-path RNN: efficient long sequence modeling for time-domain single-channel speech separation https://arxiv.org/abs/1910.06379
